﻿namespace AtividadeCalculadora
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClean = new System.Windows.Forms.Button();
            this.btnSomar = new System.Windows.Forms.Button();
            this.btnSubtrair = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnPorcentagem = new System.Windows.Forms.Button();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnnumero1 = new System.Windows.Forms.Button();
            this.btnnumero2 = new System.Windows.Forms.Button();
            this.btnnumero9 = new System.Windows.Forms.Button();
            this.btnnumero8 = new System.Windows.Forms.Button();
            this.btnnumero7 = new System.Windows.Forms.Button();
            this.btnnumero6 = new System.Windows.Forms.Button();
            this.btnnumero5 = new System.Windows.Forms.Button();
            this.btnnumero4 = new System.Windows.Forms.Button();
            this.btnnumero3 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnClean
            // 
            this.btnClean.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnClean.Location = new System.Drawing.Point(474, 131);
            this.btnClean.Name = "btnClean";
            this.btnClean.Size = new System.Drawing.Size(75, 23);
            this.btnClean.TabIndex = 0;
            this.btnClean.Text = "C";
            this.btnClean.UseVisualStyleBackColor = false;
            this.btnClean.Click += new System.EventHandler(this.btnClean_Click);
            // 
            // btnSomar
            // 
            this.btnSomar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSomar.Location = new System.Drawing.Point(172, 257);
            this.btnSomar.Name = "btnSomar";
            this.btnSomar.Size = new System.Drawing.Size(75, 23);
            this.btnSomar.TabIndex = 1;
            this.btnSomar.Text = "+";
            this.btnSomar.UseVisualStyleBackColor = false;
            // 
            // btnSubtrair
            // 
            this.btnSubtrair.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnSubtrair.Location = new System.Drawing.Point(172, 214);
            this.btnSubtrair.Name = "btnSubtrair";
            this.btnSubtrair.Size = new System.Drawing.Size(75, 23);
            this.btnSubtrair.TabIndex = 2;
            this.btnSubtrair.Text = "-";
            this.btnSubtrair.UseVisualStyleBackColor = false;
            this.btnSubtrair.Click += new System.EventHandler(this.btnSubtrair_Click);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnMultiplicar.Location = new System.Drawing.Point(172, 172);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(75, 23);
            this.btnMultiplicar.TabIndex = 3;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = false;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // btnPorcentagem
            // 
            this.btnPorcentagem.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnPorcentagem.Location = new System.Drawing.Point(377, 131);
            this.btnPorcentagem.Name = "btnPorcentagem";
            this.btnPorcentagem.Size = new System.Drawing.Size(75, 23);
            this.btnPorcentagem.TabIndex = 5;
            this.btnPorcentagem.Text = "%";
            this.btnPorcentagem.UseVisualStyleBackColor = false;
            this.btnPorcentagem.Click += new System.EventHandler(this.btnPorcentagem_Click);
            // 
            // btnDividir
            // 
            this.btnDividir.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnDividir.Location = new System.Drawing.Point(286, 129);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(75, 25);
            this.btnDividir.TabIndex = 6;
            this.btnDividir.Text = "÷";
            this.btnDividir.UseVisualStyleBackColor = false;
            this.btnDividir.Click += new System.EventHandler(this.btnDividir_Click);
            // 
            // btnnumero1
            // 
            this.btnnumero1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero1.Location = new System.Drawing.Point(286, 257);
            this.btnnumero1.Name = "btnnumero1";
            this.btnnumero1.Size = new System.Drawing.Size(75, 23);
            this.btnnumero1.TabIndex = 7;
            this.btnnumero1.Text = "1";
            this.btnnumero1.UseVisualStyleBackColor = false;
            // 
            // btnnumero2
            // 
            this.btnnumero2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero2.Location = new System.Drawing.Point(377, 257);
            this.btnnumero2.Name = "btnnumero2";
            this.btnnumero2.Size = new System.Drawing.Size(75, 23);
            this.btnnumero2.TabIndex = 8;
            this.btnnumero2.Text = "2";
            this.btnnumero2.UseVisualStyleBackColor = false;
            // 
            // btnnumero9
            // 
            this.btnnumero9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero9.Location = new System.Drawing.Point(474, 172);
            this.btnnumero9.Name = "btnnumero9";
            this.btnnumero9.Size = new System.Drawing.Size(75, 23);
            this.btnnumero9.TabIndex = 10;
            this.btnnumero9.Text = "9";
            this.btnnumero9.UseVisualStyleBackColor = false;
            // 
            // btnnumero8
            // 
            this.btnnumero8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero8.Location = new System.Drawing.Point(377, 172);
            this.btnnumero8.Name = "btnnumero8";
            this.btnnumero8.Size = new System.Drawing.Size(75, 23);
            this.btnnumero8.TabIndex = 11;
            this.btnnumero8.Text = "8";
            this.btnnumero8.UseVisualStyleBackColor = false;
            // 
            // btnnumero7
            // 
            this.btnnumero7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero7.Location = new System.Drawing.Point(286, 172);
            this.btnnumero7.Name = "btnnumero7";
            this.btnnumero7.Size = new System.Drawing.Size(75, 23);
            this.btnnumero7.TabIndex = 12;
            this.btnnumero7.Text = "7";
            this.btnnumero7.UseVisualStyleBackColor = false;
            // 
            // btnnumero6
            // 
            this.btnnumero6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero6.Location = new System.Drawing.Point(474, 214);
            this.btnnumero6.Name = "btnnumero6";
            this.btnnumero6.Size = new System.Drawing.Size(75, 23);
            this.btnnumero6.TabIndex = 13;
            this.btnnumero6.Text = "6";
            this.btnnumero6.UseVisualStyleBackColor = false;
            // 
            // btnnumero5
            // 
            this.btnnumero5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero5.Location = new System.Drawing.Point(377, 214);
            this.btnnumero5.Name = "btnnumero5";
            this.btnnumero5.Size = new System.Drawing.Size(75, 23);
            this.btnnumero5.TabIndex = 14;
            this.btnnumero5.Text = "5";
            this.btnnumero5.UseVisualStyleBackColor = false;
            // 
            // btnnumero4
            // 
            this.btnnumero4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero4.Location = new System.Drawing.Point(286, 214);
            this.btnnumero4.Name = "btnnumero4";
            this.btnnumero4.Size = new System.Drawing.Size(75, 23);
            this.btnnumero4.TabIndex = 15;
            this.btnnumero4.Text = "4";
            this.btnnumero4.UseVisualStyleBackColor = false;
            // 
            // btnnumero3
            // 
            this.btnnumero3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btnnumero3.Location = new System.Drawing.Point(474, 258);
            this.btnnumero3.Name = "btnnumero3";
            this.btnnumero3.Size = new System.Drawing.Size(75, 23);
            this.btnnumero3.TabIndex = 16;
            this.btnnumero3.Text = "3";
            this.btnnumero3.UseVisualStyleBackColor = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnnumero3);
            this.Controls.Add(this.btnnumero4);
            this.Controls.Add(this.btnnumero5);
            this.Controls.Add(this.btnnumero6);
            this.Controls.Add(this.btnnumero7);
            this.Controls.Add(this.btnnumero8);
            this.Controls.Add(this.btnnumero9);
            this.Controls.Add(this.btnnumero2);
            this.Controls.Add(this.btnnumero1);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnPorcentagem);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnSubtrair);
            this.Controls.Add(this.btnSomar);
            this.Controls.Add(this.btnClean);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnClean;
        private System.Windows.Forms.Button btnSomar;
        private System.Windows.Forms.Button btnSubtrair;
        private System.Windows.Forms.Button btnMultiplicar;
        private System.Windows.Forms.Button btnPorcentagem;
        private System.Windows.Forms.Button btnDividir;
        private System.Windows.Forms.Button btnnumero1;
        private System.Windows.Forms.Button btnnumero2;
        private System.Windows.Forms.Button btnnumero9;
        private System.Windows.Forms.Button btnnumero8;
        private System.Windows.Forms.Button btnnumero7;
        private System.Windows.Forms.Button btnnumero6;
        private System.Windows.Forms.Button btnnumero5;
        private System.Windows.Forms.Button btnnumero4;
        private System.Windows.Forms.Button btnnumero3;
    }
}

