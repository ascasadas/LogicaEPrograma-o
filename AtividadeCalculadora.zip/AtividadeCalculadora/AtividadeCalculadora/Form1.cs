﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeCalculadora
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

    

        private void btnPorcentagem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei em porsentagem");
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei em dividir");
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei em multiplicar");
        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Cliquei em subtrair");
        }

        private void btnClean_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Limpar a tela");
        }
    }
}
